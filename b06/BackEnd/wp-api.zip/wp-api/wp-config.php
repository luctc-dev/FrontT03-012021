<?php
/**
 * Cấu hình cơ bản cho WordPress
 *
 * Trong quá trình cài đặt, file "wp-config.php" sẽ được tạo dựa trên nội dung 
 * mẫu của file này. Bạn không bắt buộc phải sử dụng giao diện web để cài đặt, 
 * chỉ cần lưu file này lại với tên "wp-config.php" và điền các thông tin cần thiết.
 *
 * File này chứa các thiết lập sau:
 *
 * * Thiết lập MySQL
 * * Các khóa bí mật
 * * Tiền tố cho các bảng database
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Thiết lập MySQL - Bạn có thể lấy các thông tin này từ host/server ** //
/** Tên database MySQL */
define('DB_NAME', 'wp_api');

/** Username của database */
define('DB_USER', 'root');

/** Mật khẩu của database */
define('DB_PASSWORD', '');

/** Hostname của database */
define('DB_HOST', 'localhost');

/** Database charset sử dụng để tạo bảng database. */
define('DB_CHARSET', 'utf8');

/** Kiểu database collate. Đừng thay đổi nếu không hiểu rõ. */
define('DB_COLLATE', '');

/**#@+
 * Khóa xác thực và salt.
 *
 * Thay đổi các giá trị dưới đây thành các khóa không trùng nhau!
 * Bạn có thể tạo ra các khóa này bằng công cụ
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * Bạn có thể thay đổi chúng bất cứ lúc nào để vô hiệu hóa tất cả
 * các cookie hiện có. Điều này sẽ buộc tất cả người dùng phải đăng nhập lại.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '/r%i$r9D.%tG[jHJ:/en3rpV  Esir?bs|9?Hu=>C6$@.-h!9d=>`_i35IJ%;-~4');
define('SECURE_AUTH_KEY',  '<yZecRW*&Gi:|gN8G-t<H282ugFCnn3uirLYWug!`khR08?_]q}0-uC9{nE4#$2>');
define('LOGGED_IN_KEY',    'dvWcCzqgndk)3-Um|7TuqisBPAK#VVYIZ|QDk89*bhE|4=oG,g={mUGc|+!H4P[E');
define('NONCE_KEY',        'OP|-:BbHWuMioY=]1x^n1Q~/Y-uc-cv2$voTA Nkdv;4#CK7#$2,).M8[7=LX;5^');
define('AUTH_SALT',        'q-vl]?tOpUo`>Wdf5,^-_+v6-u8K.ZkPS0b=g9>5L&8.*:![a>Ib?}sM!vet;/2Z');
define('SECURE_AUTH_SALT', 'qSTG)F=b/?3t+Mp-^7SkfBP]$leEsL-c,UT`%^hp3o!+N3{2|BX5!;/za/QCX_P6');
define('LOGGED_IN_SALT',   '[~Ov0HU4BBdC/yY+CSW-n9a-g/vI?A0+4Y+QQK%W*&v,rzjz I8V;o|NsiJZ}O-J');
define('NONCE_SALT',       'oSkMW#g--KHr}JBG2C5-,[g9q9|K6|VvAU{l22|64dM/9|Gn`xT|58?-6b+U0EMB');

define('JWT_AUTH_SECRET_KEY', '4jS|m4pDFzU!+Cx}gPT{$t$5cei(?N#4O|/=s~Qk1N7E=Urbpvo_.z7+G{90O?TJ');

/**#@-*/

/**
 * Tiền tố cho bảng database.
 *
 * Đặt tiền tố cho bảng giúp bạn có thể cài nhiều site WordPress vào cùng một database.
 * Chỉ sử dụng số, ký tự và dấu gạch dưới!
 */
$table_prefix = 'wp_';

/**
 * Dành cho developer: Chế độ debug.
 *
 * Thay đổi hằng số này thành true sẽ làm hiện lên các thông báo trong quá trình phát triển.
 * Chúng tôi khuyến cáo các developer sử dụng WP_DEBUG trong quá trình phát triển plugin và theme.
 *
 * Để có thông tin về các hằng số khác có thể sử dụng khi debug, hãy xem tại Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* Đó là tất cả thiết lập, ngưng sửa từ phần này trở xuống. Chúc bạn viết blog vui vẻ. */

/** Đường dẫn tuyệt đối đến thư mục cài đặt WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Thiết lập biến và include file. */
require_once(ABSPATH . 'wp-settings.php');
require_once(ABSPATH . 'wp-custom-api.php');
